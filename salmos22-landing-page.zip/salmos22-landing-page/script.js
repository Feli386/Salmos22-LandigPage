/**
 * SALMO 22 - Lógica de Interactividad y Movimiento Sutil
 * Diseñado para transmitir serenidad, inocencia y contemplación.
 */

document.addEventListener('DOMContentLoaded', () => {
    initScrollReveal();
    initReadingProgress();
    initVerseFocus();
    initInnocenceParticles();
});

/**
 * 1. Aparición suave y orgánica de los versículos al desplazarse
 */
function initScrollReveal() {
    const revealElements = document.querySelectorAll('.reveal');

    const observerOptions = {
        root: null,
        rootMargin: '0px 0px -60px 0px',
        threshold: 0.15
    };

    const revealObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('visible');
            }
        });
    }, observerOptions);

    revealElements.forEach(el => revealObserver.observe(el));
}

/**
 * 2. Barra de progreso de lectura en la parte superior
 */
function initReadingProgress() {
    const progressBar = document.getElementById('readingProgress');

    window.addEventListener('scroll', () => {
        const scrollTop = window.scrollY;
        const docHeight = document.documentElement.scrollHeight - window.innerHeight;
        const scrollPercent = docHeight > 0 ? (scrollTop / docHeight) * 100 : 0;
        progressBar.style.width = `${scrollPercent}%`;
    }, { passive: true });
}

/**
 * 3. Modo Contemplación: Permite enfocar un versículo al hacer clic
 */
function initVerseFocus() {
    const verses = document.querySelectorAll('.verse');

    verses.forEach(verse => {
        verse.addEventListener('click', () => {
            const parentGrid = verse.closest('.verses-grid');
            const isAlreadyActive = verse.classList.contains('active-verse');

            // Limpiar selección previa en todas las secciones
            document.querySelectorAll('.verse.active-verse').forEach(v => {
                v.classList.remove('active-verse');
            });
            document.querySelectorAll('.verses-grid.has-focus').forEach(g => {
                g.classList.remove('has-focus');
            });

            // Si no estaba activo, lo enfocamos suavemente
            if (!isAlreadyActive) {
                verse.classList.add('active-verse');
                parentGrid.classList.add('has-focus');
            }
        });
    });
}

/**
 * 4. Brisa de Luz (Canvas): Motas de luz cálida y blanca que flotan
 *    con un movimiento ascendente muy lento y puro.
 */
function initInnocenceParticles() {
    const canvas = document.getElementById('innocenceCanvas');
    const toggleBtn = document.getElementById('toggleParticlesBtn');
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    let width = (canvas.width = window.innerWidth);
    let height = (canvas.height = window.innerHeight);
    let animationFrameId;
    let isRunning = true;

    // Ajuste al redimensionar la ventana
    window.addEventListener('resize', () => {
        width = canvas.width = window.innerWidth;
        height = canvas.height = window.innerHeight;
    });

    // Configuración de partículas suaves
    const particleCount = Math.min(38, Math.floor(width / 35));
    const particles = [];

    class LightMote {
        constructor() {
            this.reset(true);
        }

        reset(initial = false) {
            this.x = Math.random() * width;
            this.y = initial ? Math.random() * height : height + 20;
            this.radius = Math.random() * 2.8 + 1.2;
            this.speedY = Math.random() * 0.35 + 0.12; // Ascenso sumamente lento y pacífico
            this.swayAmplitude = Math.random() * 0.4 + 0.1;
            this.swaySpeed = Math.random() * 0.015 + 0.005;
            this.angle = Math.random() * Math.PI * 2;
            this.baseAlpha = Math.random() * 0.45 + 0.15;
        }

        update() {
            this.y -= this.speedY;
            this.angle += this.swaySpeed;
            this.x += Math.sin(this.angle) * this.swayAmplitude;

            if (this.y < -20) {
                this.reset(false);
            }
        }

        draw() {
            ctx.beginPath();
            const gradient = ctx.createRadialGradient(
                this.x, this.y, 0,
                this.x, this.y, this.radius * 3
            );
            // Tonos marfil y dorado champán muy translúcidos
            gradient.addColorStop(0, `rgba(255, 252, 245, ${this.baseAlpha})`);
            gradient.addColorStop(0.5, `rgba(197, 168, 128, ${this.baseAlpha * 0.5})`);
            gradient.addColorStop(1, 'rgba(250, 248, 245, 0)');

            ctx.fillStyle = gradient;
            ctx.arc(this.x, this.y, this.radius * 3, 0, Math.PI * 2);
            ctx.fill();
        }
    }

    for (let i = 0; i < particleCount; i++) {
        particles.push(new LightMote());
    }

    function animate() {
        if (!isRunning) return;
        ctx.clearRect(0, 0, width, height);

        particles.forEach(p => {
            p.update();
            p.draw();
        });

        animationFrameId = requestAnimationFrame(animate);
    }

    animate();

    // Botón para pausar o reanudar el movimiento si el lector prefiere quietud total
    if (toggleBtn) {
        toggleBtn.addEventListener('click', () => {
            isRunning = !isRunning;
            if (isRunning) {
                toggleBtn.textContent = 'Pausar brisa de luz';
                animate();
            } else {
                toggleBtn.textContent = 'Reanudar brisa de luz';
                cancelAnimationFrame(animationFrameId);
                ctx.clearRect(0, 0, width, height);
            }
        });
    }
}

// Oculta automáticamente cualquier imagen de la página si falla al cargar
window.addEventListener('error', function(event) {
  if (event.target.tagName === 'IMG') {
    event.target.style.display = 'none';
  }
}, true); // El 'true' permite capturar el error de carga por el orden de los eventos
